new Glide('.glide', {
    type: 'carousel',
    startAt: 0,
    perView: 1,
  }).mount()

  new Glide('.news_glide', {
    type: 'carousel',
    startAt: 0,
    perView: 4,
    gap: 20,
  }).mount()


new Glide('.glide_project', {
  type: 'carousel',
  startAt: 0,
  perView: 3,
  gap: 20,
}).mount()

